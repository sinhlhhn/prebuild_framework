
#import <UIKit/UIKit.h>

@interface MMLabel : UILabel

@end
