//
//  JDStatusBarLayoutMarginHelper.h
//  JDStatusBarNotificationExample
//
//  Copyright (c) 2013 Markus. All rights reserved.
//

#import <UIKit/UIKit.h>

extern UIEdgeInsets JDStatusBarRootVCLayoutMargin(void);
