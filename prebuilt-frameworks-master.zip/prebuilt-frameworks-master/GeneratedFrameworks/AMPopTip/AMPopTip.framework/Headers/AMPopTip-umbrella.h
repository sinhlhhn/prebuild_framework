#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "AMPopTip+Animation.h"
#import "AMPopTip+Draw.h"
#import "AMPopTip+Entrance.h"
#import "AMPopTip+Exit.h"
#import "AMPopTip.h"
#import "AMPopTipDefaults.h"

FOUNDATION_EXPORT double AMPopTipVersionNumber;
FOUNDATION_EXPORT const unsigned char AMPopTipVersionString[];

